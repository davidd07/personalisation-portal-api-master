module.exports.BRANDS = {
	COLES: 	'coles',
	NRMA: 	'nrma',
	RACV: 	'racv',
	AMI: 	'ami',
	CGU: 	'cgu',
	SGIC: 	'sgic',
	SGIO: 	'sgio',
	STATE: 	'state'
};