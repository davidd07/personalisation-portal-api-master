module.exports.epicTasks = [
	{
		summary: 'Ticket title 1',
		description: 'description 1'
	},
	{
		summary: 'Ticket title 2',
		description: 'description 2'
	},
	{
		summary: 'Ticket title 3',
		description: 'description 3'
	}
];